#!/usr/bin/env python
#coding=utf-8
import rospy
import sys
import glob
import threading
import binascii
import serial
import geometry_msgs.msg
import amc_base_msg.msg
import math
import time


print(sys.version)
switch_flag = 1

# 类型转换无符号整形转化成有符号整形
def type_conversion(data, len):
    if data & (1 << (len * 8 - 1)):
        data = data - (1 << (len * 8))
    return data

# 计算校验和,返回校验结果
def check_sum(data):
    data_check = 0
    for i in range(2, len(data)-1):
        data_check ^= data[i]
        data_check = data_check & 0xFF
    return data_check

# 串口连接 默认连接第一个串口
def serial_connect():
    # 搜索串口
    serial_name  = glob.glob('/dev/ttyUSB*')
    # 无可用串口时退出程序
    if len(serial_name) == 0:
        rospy.logerr("无可用串口")
        sys.exit()
    # 使用第一个USB口作为串口地址
    rospy.loginfo(serial_name[0])
    SerialPort = serial.Serial(serial_name[0], 115200, timeout=0.5)
    rospy.loginfo("连接成功")
    return SerialPort

# 获取串口数据校验并返回
def get_serial_data():
    # 接收python3数据
    data_hex = []
    if sys.version[0] == '3':
        # print(1, sys.version)
        if SerialPort.in_waiting > 0:
            # 读取数据bytes
            data = SerialPort.readline()
            # 转换成列表存储
            data_hex = list(data)
    else:
      # print(2, sys.version)
      if SerialPort.in_waiting > 0:
        data = SerialPort.readline().encode('hex') 
        for i in range(0, len(data),2):
          data_hex.append(int(data[i:i+2], 16))
          # print(data_hex)
    if len(data_hex) > 0:
      # 数据排序
      if data_hex[0] == 0x0a:
          data_hex = data_hex
      elif data_hex[0] == 0x0c:
          data_hex.insert(0, data_hex.pop())
      # 判断数据是否正确
      # print(check_sum(data_hex), data_hex[-1])
      if check_sum(data_hex) == data_hex[-1]:
          
          return data_hex
          
        # rospy.logerr("请使用python3版本运行!\n" + "当前版本为pyhton" + sys.version)
        # sys.exit()

# 发布bms信息
def publib_bms_info(pub, data):
    bms_data = amc_base_msg.msg.bms()
    # 时间戳
    bms_data.stamp=rospy.Time.now()
    # 电池容量%
    bms_data.volume_Percentage = type_conversion(data[5] | (data[6] << 8), 2)
    # 电池电流A
    bms_data.current_A = type_conversion(data[7] | (data[8] << 8), 2) / 100
    # 电池电压V
    bms_data.voltage_V = type_conversion(data[9] | (data[10] << 8), 2) / 100  
    pub.publish(bms_data)

# 发布里程信息
odom_data = amc_base_msg.msg.four_wheel_odometer()
def publib_odom_info(pub, data, cmd):
    global odom_data
    # 右车轮里程信息
    if cmd == 0x61:
        # 右后里程
        odom_data.right_back_odometer = type_conversion(data[5] | (data[6] << 8) | (data[7] << 16) | (data[8] << 24), 4)
        # 右前里程
        odom_data.right_front_odometer = type_conversion(data[9] | (data[10] << 8) | (data[11] << 16) | (data[12] << 24), 4)
    # 左车轮里程信息
    else:
        # 左前里程
        odom_data.left_front_odometer = type_conversion(data[5] | (data[6] << 8) | (data[7] << 16) | (data[8] << 24), 4)
        # 左后里程
        odom_data.left_back_odometer = type_conversion(data[9] | (data[10] << 8) | (data[11] << 16) | (data[12] << 24), 4)
        # 发送里程信息
        pub.publish(odom_data)

# 发布速度信息
speed_data = amc_base_msg.msg.four_wheel_speed()
def publib_speed_info(pub, data, cmd):
    global speed_data
    # 右车轮速度信息
    if cmd == 0x65:
        # 右后速度
        speed_data.right_back_speed = type_conversion(data[5] | (data[6] << 8) | (data[7] << 16) | (data[8] << 24), 4)
        # 右前速度
        speed_data.right_front_speed = type_conversion(data[9] | (data[10] << 8) | (data[11] << 16) | (data[12] << 24), 4)
    # 左车轮速度信息
    else:
        # 左前速度
        speed_data.left_front_speed = type_conversion(data[5] | (data[6] << 8) | (data[7] << 16) | (data[8] << 24), 4)
        # 左后速度
        speed_data.left_back_speed = type_conversion(data[9] | (data[10] << 8) | (data[11] << 16) | (data[12] << 24), 4)
        # 发送速度信息
    pub.publish(speed_data)
        

# 数据处理
def data_processing(data, odom_pub, speed_pub, bms_pub):
    # print(data
    try:
        global switch_flag
        if len(data) > 6 and data[0] == 0x0A and data[1] == 0x0C and data[-1] == check_sum(data):
            cmd = data[4]
            if (cmd == 0x61 or cmd == 0x62) and len(data) == 14:
                publib_odom_info(odom_pub, data, cmd)
            elif (cmd == 0x65 or cmd == 0x66) and len(data) == 14:
                
                publib_speed_info(speed_pub, data, cmd)
            elif cmd == 0x69 and len(data) == 14:
                publib_bms_info(bms_pub, data)
            elif cmd == 0x05:
              switch_flag = 0
        else:
            for i in range(len(data)):
                data[i] = format(data[i], 'X').zfill(2)
            rospy.logwarn(data)
    except Exception as e:
        for i in range(len(data)):
                data[i] = format(data[i], 'X').zfill(2)
        rospy.logerr(data)

# 使能
def power_on_machine():
    SerialPort.write(binascii.a2b_hex('0A'+'0C'+'01'+'00'+'01'+'01'+'01'))
    
# 失能
def power_off_machine():
    SerialPort.write(binascii.a2b_hex('0A'+'0C'+'01'+'00'+'01'+'00'+'00'))

def switch_speed_angle_model():
    global switch_flag
    while switch_flag:
      time.sleep(1)
      SerialPort.write(binascii.a2b_hex('0A'+'0C'+'01'+'00'+'05'+'00'+'04'))

# 接收数据线程
def data_receive_thread():
    # 创建BMS话题
    bms_pub = rospy.Publisher("/bms", amc_base_msg.msg.bms, queue_size=1)
    # 创建里程话题
    odom_pub = rospy.Publisher("/wheel_odom", amc_base_msg.msg.four_wheel_odometer, queue_size=1)
    # 创建速度话题
    speed_pub = rospy.Publisher("/wheel_speed", amc_base_msg.msg.four_wheel_speed, queue_size=1)
    while not rospy.is_shutdown():
        try:
            # 获取数据
            data = get_serial_data()
        except Exception as e:
            rospy.logwarn("串口连接断开！")
            rospy.signal_shutdown("串口连接断开！")
        # print(data)
        if data != None:
            # 数据处理
            
            data_processing(data, odom_pub, speed_pub, bms_pub)
    
# 处理用户下发数据
def handle_data(data):
    # 获取线速度，转换成mm/s
    linear = round(data.linear.x * 1000)
    # 获取角速度
    angular = data.angular.z

    # 线速度角速度指令
    # angular = round(angular * 1000)
    # data = [0x0A, 0x0C, 0x04, 0x00, 0x06, linear & 0xFF, (linear >> 8) & 0xFF, angular & 0xFF, (angular >> 8) & 0xFF, 0x00]

###############################################################################################################################
    # 转换成偏航角速度模式
    # LZ-600
    # length  = 270
    # width   = 194

    # LZ-PRO
    # length  = 300
    # width   = 236.5

    #LZ-STD
    length  =   210
    width   =   151

    # 速度最大值 mm/s
    vel_max =   1000
    # 角度最大值 °
    ang_max =   20
    # 原地转
    if linear == 0 and angular != 0:
        round_vel = math.sqrt(length*length + width*width) * angular
        if round_vel > vel_max:
            round_vel = vel_max
        elif round_vel < -vel_max:
            round_vel = -vel_max
        round_vel = int(round_vel) 
        data = [0x0A, 0x0C, 0x06, 0x00, 0x02, 0x00, 0x00, 0x00, 0x00, round_vel & 0xFF, (round_vel >> 8) & 0xFF, 0x00]
    else:
        vel = linear
        if vel > vel_max:
            vel = vel_max
        elif vel < -vel_max:
            vel = -vel_max
        if angular != 0:
            R = vel / angular
            if R < 0 and R > -length:
                ang = -ang_max
            elif R > 0 and R < length:
                ang = ang_max
            else:
                ang = math.sin(length / R) * 180 / math.pi
                if ang > ang_max:
                    ang = ang_max
                elif ang < -ang_max:
                    ang = -ang_max
        else:
            ang = 0
        ang = ang * 100
        vel = int(vel)
        ang = int(ang)
        data = [0x0A, 0x0C, 0x06, 0x00, 0x02, vel & 0xFF, (vel >> 8) & 0xFF, ang & 0xFF, (ang >> 8) & 0xFF, 0x00, 0x00, 0x00]
###############################################################################################################################

    # 添加校验位
    data[-1] = check_sum(data)
    # 将整数转换为十六进制字符串
    for i in range(len(data)):
        data[i] = format(data[i], 'X').zfill(2)
    # 转换成字符串数据
    data_str = ''.join(data).encode()
    # 转换成十六进制字节数据
    SerialPort.write(binascii.a2b_hex(data_str))

# 主函数
if __name__ == "__main__":
    # 初始化节点
    rospy.init_node("amc_ros_node", anonymous=True)
    # 连接串口
    SerialPort = serial_connect()
    # 订阅速度话题
    rospy.Subscriber('/cmd_vel',geometry_msgs.msg.Twist,handle_data)
    # 使能
    power_on_machine()
    #创建串口接收线程
    t = threading.Thread(target = data_receive_thread)
    s = threading.Thread(target = switch_speed_angle_model)
    t.setDaemon(True)
    s.setDaemon(True)
    t.start()
    s.start()
    while not rospy.is_shutdown():
        time.sleep(1)
    # 失能
    power_off_machine()
