cmake_minimum_required(VERSION 3.0.2)
project(amc_base_serial)

find_package(catkin REQUIRED COMPONENTS
  std_msgs
  roscpp
  rospy
  tf
  amc_base_msg
)

catkin_package(
#  INCLUDE_DIRS include
#  LIBRARIES hello_world
 CATKIN_DEPENDS roscpp rospy std_msgs tf  
#  DEPENDS system_lib
)

include_directories(
  include
  ${catkin_INCLUDE_DIRS}
)



catkin_install_python(PROGRAMS
  scripts/amc_base_node_serial.py
  DESTINATION ${CATKIN_PACKAGE_BIN_DESTINATION}
)
