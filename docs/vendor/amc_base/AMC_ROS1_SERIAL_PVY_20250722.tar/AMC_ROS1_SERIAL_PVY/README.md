#### 一、文件结构
```
AMC_ROS1_SERIAL_PVY
└─ src
   ├─ amc_base_serial
   │  ├─ CMakeLists.txt  ------  描述编译规则，如源文件、依赖项、目标文件
   │  ├─ package.xml  ------  定义功能包的属性，如包名、版本号、作者、依赖等
   │  └─ scripts  ------  存放python源文件
   │     └─ amc_base_node_serial.py
   └─ amc_base_msg
      ├─ CMakeLists.txt  ------  描述编译规则，如源文件、依赖项、目标文件
      ├─ msg
      │  ├─ bms.msg  ------  电池信息
      │  ├─ four_wheel_odometer_can.msg  ------  车轮里程
      │  └─ four_wheel_speed_can.msg  ------  车轮速度
      └─ package.xml  ------  定义功能包的属性，如包名、版本号、作者、依赖等
```


#### 二、 话题

1. /wheel_odom
```
      right_front_odometer        右前车轮里程
      right_back_odometer         右后车轮里程
      left_front_odometer         左前车轮里程
      left_back_odometer          左后车轮里程
```

2. /wheel_speed
```
      right_front_speed           右前车轮速度
      right_back_speed            右后车轮速度
      left_front_speed            左前车轮速度
      left_back_speed             左后车轮里程
```

3. /bms
```
      voltage_V                   电池电压
      current_A                   电池电流
      volume_Percentage           电池电量
```

#### 三、运行步骤

1. 运行ROS Master
```
      roscore
```

2. 为python文件添加可执行权限
```
      cd AMC_ROS1_SERIAL_PVY/src/amc_base_serial/scripts
      chmod +x *.py
```

3. 编译工程

```
      cd AMC_ROS1_SERIAL_PVY
      catkin_make
```

4. 配置工作空间,刷新环境

```
      source ./devel/setup.bash
```

5. 运行程序
```
      rosrun amc_base_serial amc_base_node_serial.py
```


