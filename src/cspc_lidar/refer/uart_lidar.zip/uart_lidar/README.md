# M1CT-D2 激光雷达驱动

## 1. 项目概述

M1CT-D2 激光雷达驱动是基于 UART 串口通信的 C 语言实现，用于读取和解析 M1CT_Coin_D2/COIN-D6 型号激光雷达的数据。该驱动支持标准的 OpenHarmony 系统，可在 Unionpi_Whale 开发板上运行。

## 2. 驱动架构层次

```
M1CT-D2 激光雷达驱动
├── 应用层 (main.c)
│   ├── 命令行参数解析
│   ├── 信号处理
│   └── 数据处理线程管理
├── 雷达数据处理层 (lidar_data_processing.c/h)
│   ├── 雷达数据包解析
│   ├── 数据校验
│   └── 角度计算
├── 雷达信息管理层 (lidar_information.c/h)
│   ├── 激光扫描数据结构
│   ├── 雷达控制命令
│   └── 激光点云管理
├── 串口通信层 (serial_port.c/h)
│   ├── 串口设备管理
│   ├── 数据读写
│   └── 超时控制
├── 底层串口接口 (uart_base.c/h)
│   ├── 串口设备打开/关闭
│   ├── 波特率配置
│   └── 数据收发
├── 时间管理模块 (mtime.c/h)
│   ├── 时间获取
│   └── 延时函数
└── 线程同步模块 (locker.c/h)
    ├── 互斥锁
    └── 条件变量
```

### 2.1 应用层 (Application Layer)

应用层是驱动程序的入口点，主要负责：
- 解析命令行参数
- 初始化系统资源
- 管理数据处理线程
- 处理系统信号（如 Ctrl+C）

主要文件：
- [main.c](src/main.c) - 主程序入口

### 2.2 雷达数据处理层 (Lidar Data Processing Layer)

雷达数据处理层负责解析从串口接收到的原始数据包，提取有用信息：
- 解析 COIN-D6 协议数据包
- 校验数据完整性
- 计算激光点的角度和距离
- 判断扫描圈的起始点

主要文件：
- [lidar_data_processing.c](src/lidar_data_processing.c) - 数据处理实现
- [lidar_data_processing.h](include/lidar_data_processing.h) - 数据处理接口

### 2.3 雷达信息管理层 (Lidar Information Management Layer)

雷达信息管理层定义了激光雷达相关的数据结构和控制命令：
- 激光扫描数据结构定义
- 雷达控制命令常量
- 激光点云数据管理

主要文件：
- [lidar_information.c](src/lidar_information.c) - 信息管理实现
- [lidar_information.h](include/lidar_information.h) - 信息管理接口

### 2.4 串口通信层 (Serial Port Communication Layer)

串口通信层封装了串口设备的操作，提供了更易用的接口：
- 串口设备的创建和销毁
- 数据读写操作
- 超时和缓冲区管理

主要文件：
- [serial_port.c](src/serial_port.c) - 串口通信实现
- [serial_port.h](include/serial_port.h) - 串口通信接口

### 2.5 底层串口接口 (Low-level Serial Interface)

底层串口接口提供了对串口设备的基本操作：
- 串口设备的打开和关闭
- 波特率和数据格式配置
- 原始数据收发

主要文件：
- [uart_base.c](src/uart_base.c) - 底层串口实现
- [uart_base.h](include/uart_base.h) - 底层串口接口

### 2.6 时间管理模块 (Time Management Module)

时间管理模块提供了时间相关的工具函数：
- 获取当前时间
- 毫秒延时功能

主要文件：
- [mtime.c](src/mtime.c) - 时间管理实现
- [mtime.h](include/mtime.h) - 时间管理接口

### 2.7 线程同步模块 (Thread Synchronization Module)

线程同步模块提供了线程间同步的工具：
- 互斥锁操作
- 条件变量管理

主要文件：
- [locker.c](src/locker.c) - 线程同步实现
- [locker.h](include/locker.h) - 线程同步接口

## 3. 数据流说明

1. 应用层通过命令行参数指定串口设备路径和波特率
2. 初始化串口设备并发送启动命令
3. 创建数据处理线程，持续从串口读取数据
4. 解析雷达数据包，提取角度、距离和强度信息
5. 输出解析后的点云数据到控制台

## 4. 编译和运行

### 4.1 编译方法

```bash
# 在 OpenHarmony 源码根目录下执行
./build.sh --product-name Unionpi_Whale_demo --ccache
```

### 4.2 运行方法

```bash
# 启动雷达驱动，指定串口设备和波特率
./uart_lidar --uart-port /dev/ttyUSB0 --baudrate 230400
```

## 5. 控制协议

### 5.1 启动命令
- 数据: `0xAA 0x55 0xF0 0x0F`
- 功能: 启动雷达扫描

### 5.2 停止命令
- 数据: `0xAA 0x55 0xF5 0x0A`
- 功能: 停止雷达扫描

### 5.3 数据包格式 (COIN-D6)

数据包头:
- 0xAA 0x55 - 包头标识
- CT - 类型字节
- LSN - 采样点数量
- FSA - 起始角度
- LSA - 结束角度
- CS - 校验码

采样点数据:
- 每个采样点占用3字节
- Si_L - 低字节
- Si_2nd - 第二字节
- Si_H - 高字节

距离计算: Distance(mm) = Si_H * 64 + (Si_2nd >> 2)
强度计算: Intensity = (Si_2nd & 0x03) * 64 + (Si_L >> 2)
高反标志: High_Reflection_Flag = Si_L & 0x01

## 6. Python GUI 程序

### 6.1 概述

提供了一个Python程序 `lidar_gui.py`，用于实时可视化雷达点云数据。该程序解析雷达驱动的终端输出，并在GUI界面中绘制点云图。

### 6.2 依赖项

- Python 3.x
- matplotlib
- numpy

### 6.3 安装依赖

```bash
pip install -r requirements.txt
```

### 6.4 使用方法

1. 确保雷达驱动程序`lidar_driver`在当前目录中，并且可执行。
2. 确保串口`/dev/ttyUSB0`可用。
3. 运行程序：

```bash
python lidar_gui.py
```

程序将启动雷达驱动，读取输出，并显示实时点云图。

### 6.5 功能说明

- 使用极坐标绘制点云。
- 颜色根据强度变化（viridis色图）。
- 实时更新，每100ms刷新一次。
- 限制显示最近1000个点以优化性能。

### 6.6 注意事项

- 需要root权限或适当权限访问串口。
- 如果雷达驱动失败，检查串口路径和波特率。
- 程序假设输出格式为示例中的格式。