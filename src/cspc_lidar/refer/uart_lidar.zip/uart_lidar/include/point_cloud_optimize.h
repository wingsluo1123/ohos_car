/*
 * @Author: WARDEN equinoxf@petalmail.com
 * @Date: 2025-11-01
 * @FilePath: /OpenHarmony/unionpi_whale_demo/uart_lidar/include/point_cloud_optimize.h
 * @Description: 点云优化模块头文件 (占位文件)
 */

#ifndef POINT_CLOUD_OPTIMIZE_H
#define POINT_CLOUD_OPTIMIZE_H

#ifdef __cplusplus
extern "C"
{
#endif

    /* 占位结构 */
    typedef struct 
    {
        int dummy;
    } Point_cloud_optimize;

#ifdef __cplusplus
}
#endif

#endif
