import subprocess
import threading
import re
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
import numpy as np

# 解析终端输出行的函数
def parse_line(line):
    # 使用正则表达式匹配输出格式
    match = re.search(r'Angle:\s*([-\d.]+)°\s*Distance:\s*(\d+)\s*mm\s*Intensity:\s*(\d+)', line)
    if match:
        angle = float(match.group(1))
        distance = int(match.group(2))
        intensity = int(match.group(3))
        return angle, distance, intensity
    return None

# 存储点云数据的列表
points = []

# 读取进程输出的线程函数
def read_output(process):
    for line in iter(process.stdout.readline, b''):
        line = line.decode('utf-8').strip()
        data = parse_line(line)
        if data:
            points.append(data)
            # 限制点数以避免内存溢出，保持最近的1000个点
            if len(points) > 1000:
                points.pop(0)

# 主函数
def main():
    # 启动雷达驱动命令
    cmd = ['./lidar_driver', '--uart-port', '/dev/ttyUSB0', '--baudrate', '230400']
    process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    
    # 启动读取输出的线程
    thread = threading.Thread(target=read_output, args=(process,))
    thread.daemon = True
    thread.start()
    
    # 设置matplotlib图形，使用极坐标
    fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})
    ax.set_rlim(0, 2)  # 设置半径范围为0到2米
    ax.set_title('Real-time Lidar Point Cloud')
    
    # 初始化散点图
    scatter = ax.scatter([], [], c=[], cmap='viridis', s=1, alpha=0.7)
    
    # 动画更新函数
    def update(frame):
        if points:
            # 提取角度、距离和强度
            angles = np.array([p[0] for p in points]) * np.pi / 180  # 角度转换为弧度
            distances = np.array([p[1] for p in points]) / 1000  # 距离从mm转换为m
            intensities = np.array([p[2] for p in points])
            
            # 更新散点图
            scatter.set_offsets(np.column_stack((angles, distances)))
            scatter.set_array(intensities)
        return scatter,
    
    # 创建动画，每100ms更新一次
    ani = FuncAnimation(fig, update, interval=100, blit=True)
    
    # 显示图形
    plt.show()
    
    # 等待进程结束
    process.wait()

if __name__ == '__main__':
    main()